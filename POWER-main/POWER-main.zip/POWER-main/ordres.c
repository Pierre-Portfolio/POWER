#include "stdio.h"
#include <stdlib.h>
#include <string.h>

#include <windows.h>

#include "definition.h"
#include "Initialisation.h"
#include "ordres.h"


//void saisir_ordres(S_ordres tab_ordres[]){









//}
