#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>

#include "definition.h"
#include "Initialisation.h"
#include "game.h"
#include "util.h"

int main()
{
    // on cr�e une partie
    S_game g1=creer_game();
    g1=jouer_game(g1);
    printf("La partie est terminee, le gagnant est : le joueur %d",g1.gagnant_partie+1);
    return 0;
}



