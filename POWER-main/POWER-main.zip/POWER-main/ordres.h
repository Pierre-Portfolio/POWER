#ifndef ORDRES_H_INCLUDED
#define ORDRES_H_INCLUDED



//void saisir_ordres(S_ordres tab_ordres[]);
//void verifier_ordres();
//void effectuer_ordres();

#endif // ORDRES_H_INCLUDED
