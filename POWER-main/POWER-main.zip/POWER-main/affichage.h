#ifndef AFFICHAGE_H_INCLUDED
#define AFFICHAGE_H_INCLUDED

//void page_de_garde();

void ecriture(char texte[]);

#endif // AFFICHAGE_H_INCLUDED
